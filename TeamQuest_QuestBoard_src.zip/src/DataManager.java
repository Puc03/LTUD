import java.util.ArrayList;
import java.util.List;
import com.google.gson.Gson;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class DataManager {
    // 1. Áp dụng Singleton Pattern: Chỉ cho phép tạo 1 DataManager duy nhất toàn hệ thống
    private static DataManager instance;

    // Các danh sách dữ liệu tổng của toàn bộ ứng dụng
    private List<User> allUsers;
    private List<Project> allProjects;
    private List<Team> allTeams;

    // Biến instance riêng tư
    private DataManager() {
        this.allUsers = new ArrayList<>();
        this.allProjects = new ArrayList<>();
        this.allTeams = new ArrayList<>();
    }

    // Hàm gọi DataManager ra để dùng
    public static DataManager getInstance() {
        if (instance == null) {
            instance = new DataManager();
        }
        return instance;
    }

    // KHU VỰC 2: LOGIC LƯU VÀ ĐỌC FILE JSON

    public void saveAllData() {
        Gson gson = new Gson();
        try (FileWriter writer = new FileWriter("database.json")) {
            gson.toJson(this, writer);
            System.out.println("Đã lưu dữ liệu thành công vào database.json!");
        } catch (IOException e) {
            System.out.println("Lỗi khi lưu dữ liệu: " + e.getMessage());
        }
    }

    public void loadAllData() {
        Gson gson = new Gson();
        try (FileReader reader = new FileReader("database.json")) {
            DataManager loadedData = gson.fromJson(reader, DataManager.class);
            if (loadedData != null) {
                this.allUsers = loadedData.allUsers;
                this.allProjects = loadedData.allProjects;
                this.allTeams = loadedData.allTeams;
                System.out.println("Đã tải dữ liệu thành công từ file!");
            }
        } catch (IOException e) {
            System.out.println("Chưa có file dữ liệu cũ, hệ thống sẽ tạo mới khi bạn lưu.");
        }
    }
}