public class PlayerProfile {
    // Dùng private (-) để bảo vệ dữ liệu
    private int xp;
    private int level;
    private int coin;
    private int hp;
    private int maxHp;
    private int reputation;

    public PlayerProfile() {
        this.xp = 0;
        this.level = 1;
        this.coin = 0;
        this.maxHp = 1000;
        this.hp = 1000;
        this.reputation = 100;
    }

    // Behavior làm thay đổi State
    public void gainXp(int amount) {
        if (amount > 0) {
            this.xp += amount;
            checkLevelUp(); // Gọi hàm nội bộ để tự tăng level nếu đủ điểm
        }
    }

    // [MỚI - có trong UML] cộng coin
    public void addCoin(int amount) {
        if (amount > 0) this.coin += amount;
    }

    public void loseHp(int amount) {
        this.hp -= amount;
        if (this.hp < 0) this.hp = 0;
    }

    // XP cần để lên level kế tiếp (chỉnh công thức ở đây)
    public int getXpToNextLevel() { return level * 100; }

    private void checkLevelUp() {
        while (xp >= getXpToNextLevel()) {
            xp -= getXpToNextLevel();
            levelUp();
        }
    }

    // [UML: levelUp() public] tăng level và hồi đầy máu
    public void levelUp() {
        level++;
        hp = maxHp;
    }

    public boolean isWarned() {
        return this.hp < 200; // Cảnh báo nếu máu đỏ
    }

    // [MỚI] Getter cho GUI
    public int getXp() { return xp; }
    public int getLevel() { return level; }
    public int getCoin() { return coin; }
    public int getHp() { return hp; }
    public int getMaxHp() { return maxHp; }
    public int getReputation() { return reputation; }
}
