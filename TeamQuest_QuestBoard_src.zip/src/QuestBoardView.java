import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Calendar;
import java.util.Date;
import java.util.function.Predicate;

/**
 * [VIEW] Màn hình QuestBoard (Swing). Chỉ dựng giao diện + cung cấp getter/setter,
 * KHÔNG chứa logic nghiệp vụ. Mọi Listener được gắn ở QuestBoardController.
 *
 * Bố cục (BorderLayout):
 *   NORTH  : thanh chọn người dùng (giả lập đăng nhập) + thông tin PlayerProfile
 *   WEST   : form chi tiết Task (GridBagLayout) + cụm nút chức năng (GridLayout)
 *   CENTER : thanh lọc (FlowLayout) + JTable trong JScrollPane
 *   SOUTH  : thanh trạng thái
 */
public class QuestBoardView extends JFrame {

    // ---- Thanh người dùng ----
    private final JComboBox<User> cbCurrentUser = new JComboBox<>();
    private final JLabel lblProfile = new JLabel(" ");

    // ---- Form Task ----
    private final JTextField tfTaskId = new JTextField(18);
    private final JTextField tfTitle = new JTextField(18);
    private final JTextArea taDescription = new JTextArea(5, 18);
    private final JComboBox<Difficulty> cbDifficulty = new JComboBox<>(Difficulty.values());
    private final JSpinner spDeadline;   // Swing không có DatePicker sẵn -> JSpinner ngày+giờ
    private final JComboBox<TaskStatus> cbStatus = new JComboBox<>(TaskStatus.values());

    // ---- Nút chức năng ----
    private final JButton btnPost = new JButton("Post Task");
    private final JButton btnClaim = new JButton("Claim Task");
    private final JButton btnSubmit = new JButton("Submit");
    private final JButton btnApprove = new JButton("Approve");
    private final JButton btnReject = new JButton("Reject");
    private final JButton btnAutoAssign = new JButton("Auto-Assign");
    private final JButton btnClear = new JButton("Clear Form");

    // ---- Bảng + bộ lọc ----
    private final TaskTableModel tableModel = new TaskTableModel();
    private final JTable table = new JTable(tableModel);
    private final JComboBox<Object> cbFilterStatus = new JComboBox<>();
    private final JComboBox<Object> cbFilterDifficulty = new JComboBox<>();

    private final JLabel lblStatusBar = new JLabel(" ");

    // Tô đỏ dòng "khẩn cấp" (do controller cung cấp, lấy từ SmartAssigner)
    private Predicate<Task> urgentPredicate = t -> false;

    public QuestBoardView() {
        super("TEAM-QUEST | QuestBoard - Task Management");

        // Deadline: JSpinner với SpinnerDateModel, hiển thị dd/MM/yyyy HH:mm
        spDeadline = new JSpinner(new SpinnerDateModel(new Date(), null, null, Calendar.MINUTE));
        spDeadline.setEditor(new JSpinner.DateEditor(spDeadline, "dd/MM/yyyy HH:mm"));

        // Bộ lọc: phần tử đầu là "ALL" (= không lọc), phần còn lại là Enum
        cbFilterStatus.addItem("ALL");
        for (TaskStatus s : TaskStatus.values()) cbFilterStatus.addItem(s);
        cbFilterDifficulty.addItem("ALL");
        for (Difficulty d : Difficulty.values()) cbFilterDifficulty.addItem(d);

        // Status chỉ để XEM: trạng thái đổi qua workflow (Claim -> Submit -> Approve/Reject).
        // Muốn cho gõ tay thì đổi thành setEnabled(true).
        cbStatus.setEnabled(false);
        taDescription.setLineWrap(true);
        taDescription.setWrapStyleWord(true);

        buildLayout();
        setupTable();

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1100, 620);
        setMinimumSize(new Dimension(900, 520));
        setLocationRelativeTo(null);
    }

    // ======================= Dựng layout =======================
    private void buildLayout() {
        setLayout(new BorderLayout(8, 8));
        ((JComponent) getContentPane()).setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

        // NORTH: 2 dòng (GridLayout) - dòng 1 chọn user, dòng 2 thông tin PlayerProfile
        JPanel north = new JPanel(new GridLayout(2, 1, 0, 2));
        JPanel userRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 2));
        userRow.add(new JLabel("Logged in as:"));
        userRow.add(cbCurrentUser);
        JPanel profileRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 2));
        profileRow.add(lblProfile);
        north.add(userRow);
        north.add(profileRow);
        add(north, BorderLayout.NORTH);

        // WEST: form + nút
        JPanel west = new JPanel(new BorderLayout(0, 10));
        west.add(buildFormPanel(), BorderLayout.CENTER);
        west.add(buildButtonPanel(), BorderLayout.SOUTH);
        west.setPreferredSize(new Dimension(340, 0));
        add(west, BorderLayout.WEST);

        // CENTER: filter + table
        JPanel center = new JPanel(new BorderLayout(0, 6));
        JPanel filterBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 2));
        filterBar.add(new JLabel("Filter status:"));
        filterBar.add(cbFilterStatus);
        filterBar.add(new JLabel("Difficulty:"));
        filterBar.add(cbFilterDifficulty);
        center.add(filterBar, BorderLayout.NORTH);
        center.add(new JScrollPane(table), BorderLayout.CENTER);
        center.setBorder(BorderFactory.createTitledBorder("Quest List"));
        add(center, BorderLayout.CENTER);

        // SOUTH
        add(lblStatusBar, BorderLayout.SOUTH);
    }

    private JPanel buildFormPanel() {
        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(BorderFactory.createTitledBorder("Task Details"));
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(4, 4, 4, 4);
        gc.anchor = GridBagConstraints.NORTHWEST;

        addRow(form, gc, 0, "Task ID:", tfTaskId);
        addRow(form, gc, 1, "Title:", tfTitle);
        addRow(form, gc, 2, "Description:", new JScrollPane(taDescription));
        addRow(form, gc, 3, "Difficulty:", cbDifficulty);
        addRow(form, gc, 4, "Deadline:", spDeadline);
        addRow(form, gc, 5, "Status:", cbStatus);

        // Hàng đệm ăn hết phần dư theo chiều dọc -> các ô nhập dồn lên trên, không bị canh giữa
        gc.gridx = 0; gc.gridy = 6; gc.gridwidth = 2; gc.weighty = 1; gc.fill = GridBagConstraints.VERTICAL;
        form.add(new JPanel(), gc);
        return form;
    }

    private void addRow(JPanel p, GridBagConstraints gc, int row, String label, JComponent field) {
        gc.gridy = row;
        gc.gridx = 0; gc.weightx = 0; gc.fill = GridBagConstraints.NONE;
        p.add(new JLabel(label), gc);
        gc.gridx = 1; gc.weightx = 1; gc.fill = GridBagConstraints.HORIZONTAL;
        p.add(field, gc);
    }

    private JPanel buildButtonPanel() {
        JPanel buttons = new JPanel(new GridLayout(0, 2, 6, 6));
        buttons.setBorder(BorderFactory.createTitledBorder("Actions"));
        buttons.add(btnPost);
        buttons.add(btnAutoAssign);
        buttons.add(btnClaim);
        buttons.add(btnSubmit);
        buttons.add(btnApprove);
        buttons.add(btnReject);
        buttons.add(btnClear);
        return buttons;
    }

    private void setupTable() {
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setRowHeight(24);
        table.setAutoCreateRowSorter(true);   // bấm tiêu đề cột để sắp xếp
        // Renderer: tô đỏ nhạt task khẩn cấp
        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable tb, Object v, boolean sel,
                                                           boolean focus, int row, int col) {
                Component c = super.getTableCellRendererComponent(tb, v, sel, focus, row, col);
                if (!sel) {
                    Task t = tableModel.getTaskAt(tb.convertRowIndexToModel(row));
                    c.setBackground(urgentPredicate.test(t) ? new Color(255, 225, 225) : Color.WHITE);
                }
                return c;
            }
        });
    }

    // ======================= API cho Controller =======================
    // -- Form --
    public String getTaskIdText() { return tfTaskId.getText().trim(); }
    public String getTitleText() { return tfTitle.getText().trim(); }
    public String getDescriptionText() { return taDescription.getText().trim(); }
    public Difficulty getSelectedDifficulty() { return (Difficulty) cbDifficulty.getSelectedItem(); }

    public LocalDateTime getDeadline() {
        try { spDeadline.commitEdit(); } catch (java.text.ParseException ignored) { /* giữ giá trị cũ */ }
        Date d = (Date) spDeadline.getValue();
        return LocalDateTime.ofInstant(d.toInstant(), ZoneId.systemDefault());
    }

    private void setDeadline(LocalDateTime dt) {
        spDeadline.setValue(Date.from(dt.atZone(ZoneId.systemDefault()).toInstant()));
    }

    /** Đổ dữ liệu một Task lên form (dùng khi click dòng trong bảng). taskId khóa lại vì là khóa chính. */
    public void showTask(Task t) {
        tfTaskId.setText(t.getTaskId());
        tfTaskId.setEditable(false);
        tfTitle.setText(t.getTitle());
        taDescription.setText(t.getDescription());
        cbDifficulty.setSelectedItem(t.getDifficulty());
        if (t.getDeadline() != null) setDeadline(t.getDeadline());
        cbStatus.setSelectedItem(t.getStatus());
    }

    /** Xóa form để nhập Task mới với ID gợi ý. */
    public void clearForm(String suggestedId) {
        tfTaskId.setText(suggestedId);
        tfTaskId.setEditable(true);
        tfTitle.setText("");
        taDescription.setText("");
        cbDifficulty.setSelectedItem(Difficulty.EASY);
        setDeadline(LocalDateTime.now().plusDays(3));
        cbStatus.setSelectedItem(TaskStatus.TODO);
        table.clearSelection();
    }

    // -- Bảng / bộ lọc --
    public TaskTableModel getTableModel() { return tableModel; }
    public JTable getTable() { return table; }
    public void setUrgentPredicate(Predicate<Task> p) { this.urgentPredicate = p; }

    /** null = "ALL". */
    public TaskStatus getFilterStatus() {
        return cbFilterStatus.getSelectedItem() instanceof TaskStatus s ? s : null;
    }
    public Difficulty getFilterDifficulty() {
        return cbFilterDifficulty.getSelectedItem() instanceof Difficulty d ? d : null;
    }

    /** Task đang chọn trong bảng (null nếu chưa chọn). Tự đổi chỉ số view -> model vì bảng có sorter. */
    public Task getSelectedTask() {
        int viewRow = table.getSelectedRow();
        return viewRow < 0 ? null : tableModel.getTaskAt(table.convertRowIndexToModel(viewRow));
    }

    public void selectTask(Task t) {
        int modelRow = tableModel.indexOf(t);
        if (modelRow < 0) return;
        int viewRow = table.convertRowIndexToView(modelRow);
        table.getSelectionModel().setSelectionInterval(viewRow, viewRow);
    }

    // -- Người dùng / thông báo --
    public JComboBox<User> getUserCombo() { return cbCurrentUser; }
    public void setProfileText(String s) { lblProfile.setText(s); }
    public void setStatusBar(String s) { lblStatusBar.setText(" " + s); }

    // -- Getter nút / combo để Controller gắn Listener --
    public JButton getBtnPost() { return btnPost; }
    public JButton getBtnClaim() { return btnClaim; }
    public JButton getBtnSubmit() { return btnSubmit; }
    public JButton getBtnApprove() { return btnApprove; }
    public JButton getBtnReject() { return btnReject; }
    public JButton getBtnAutoAssign() { return btnAutoAssign; }
    public JButton getBtnClear() { return btnClear; }
    public JComboBox<Object> getCbFilterStatus() { return cbFilterStatus; }
    public JComboBox<Object> getCbFilterDifficulty() { return cbFilterDifficulty; }
}
