import java.time.LocalDateTime;

/**
 * Submission theo UML: submissionId, submittedAt, filePath, note, status.
 * [BỔ SUNG so với UML] thêm 2 tham chiếu: task và submitter, vì Leader cần biết
 * bài nộp này của Task nào / của Member nào để duyệt và trao thưởng.
 * -> nên vẽ thêm 2 association Submission->Task, Submission->Member vào sơ đồ.
 */
public class Submission {
    private String submissionId;
    private Task task;
    private Member submitter;
    private LocalDateTime submittedAt;
    private String filePath;
    private String note;
    private TaskStatus status;

    public Submission(String submissionId, Task task, Member submitter,
                      String filePath, String note) {
        this.submissionId = submissionId;
        this.task = task;
        this.submitter = submitter;
        this.filePath = filePath;
        this.note = note;
        this.status = TaskStatus.DOING;      // chưa nộp
    }

    public void submit()  { this.submittedAt = LocalDateTime.now(); this.status = TaskStatus.REVIEW; }
    public void approve() { this.status = TaskStatus.DONE; }
    public void reject()  { this.status = TaskStatus.DOING; }   // bắt làm lại

    public String getSubmissionId() { return submissionId; }
    public Task getTask() { return task; }
    public Member getSubmitter() { return submitter; }
    public LocalDateTime getSubmittedAt() { return submittedAt; }
    public String getFilePath() { return filePath; }
    public String getNote() { return note; }
    public TaskStatus getStatus() { return status; }
}
