import javax.swing.*;

/** Điểm khởi chạy: dựng View rồi giao cho Controller. */
public class MainApp {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); }
            catch (Exception ignored) { /* dùng giao diện mặc định */ }

            QuestBoardView view = new QuestBoardView();
            new QuestBoardController(view);   // Controller tự gắn Listener + nạp dữ liệu
            view.setVisible(true);
        });
    }
}
