public interface Rewardable {
    // Chỉ định nghĩa tên hàm, các Class khác khi dùng (implements)  phần ruột
    int calculateXp();
    int calculateCoin();
}