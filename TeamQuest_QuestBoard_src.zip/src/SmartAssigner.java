import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

/** Tự động giao việc (UML: SmartAssigner). */
public class SmartAssigner {
    private int urgentThresholdHours = 24;

    public int calculateWorkload(Member member) { return member.getWorkload(); }

    // Thành viên đang rảnh nhất (workload thấp nhất) trong team
    public Member findFreestMember(Team team) {
        Member best = null;
        for (Member m : team.getMembers()) {
            if (best == null || calculateWorkload(m) < calculateWorkload(best)) best = m;
        }
        return best;
    }

    // Task chưa DONE và deadline còn <= urgentThresholdHours (hoặc đã quá hạn)
    public boolean isUrgent(Task task) {
        return task.getStatus() != TaskStatus.DONE && task.getDeadline() != null
                && !task.getDeadline().isAfter(LocalDateTime.now().plusHours(urgentThresholdHours));
    }

    public List<Task> scanUrgentTasks(Project project) {
        return project.getTasks().stream().filter(this::isUrgent).collect(Collectors.toList());
    }

    // Giao task cho người rảnh nhất
    public void autoAssign(Task task, Team team) {
        Member freest = findFreestMember(team);
        if (freest == null) throw new IllegalStateException("Team has no members.");
        if (!freest.claimTask(task)) {
            throw new IllegalStateException("Task cannot be assigned (must be TODO and unassigned).");
        }
    }
}
