import javax.swing.*;
import java.awt.GridLayout;
import java.time.LocalDateTime;
import java.util.*;

/**
 * [CONTROLLER] Cầu nối View <-> Model.
 *  - Gắn Listener cho các thành phần của QuestBoardView.
 *  - Gọi logic tuần 2: QuestBoard, Member, Leader, GamificationService, SmartAssigner.
 *  - Sau mỗi hành động luôn gọi refreshTable() + updateButtons() để giao diện đồng bộ Model.
 *
 * Tìm nhanh các điểm cần tinh chỉnh bằng cách search:
 *   "[LISTENER]"  -> chỗ gắn sự kiện
 *   "[LOGIC]"     -> chỗ gọi vào Model / Service
 */
public class QuestBoardController {

    // ---- View ----
    private final QuestBoardView view;

    // ---- Model / Service (logic tuần 2) ----
    private final QuestBoard board = new QuestBoard();
    private final GamificationService gamification = new GamificationService();
    private final SmartAssigner smartAssigner = new SmartAssigner();
    private Project project;
    private Team team;
    private Leader leader;
    private final List<User> users = new ArrayList<>();

    // Người dùng hiện tại (giả lập đăng nhập bằng combobox)
    private User currentUser;

    // Bài nộp đang chờ duyệt: taskId -> Submission.
    // (Tạm để ở Controller; sau này nên chuyển vào Model, vd. QuestBoard hoặc Task.)
    private final Map<String, Submission> pendingSubmissions = new HashMap<>();

    private int taskCounter = 0;
    private int submissionCounter = 0;

    public QuestBoardController(QuestBoardView view) {
        this.view = view;
        seedDemoData();          // bỏ dòng này khi nối với DataManager.loadAllData()
        initView();
        attachListeners();
        refreshTable();
        updateButtons();
        updateProfileInfo();
    }

    // =====================================================================
    // Dữ liệu mẫu (thay bằng DataManager.getInstance() khi đã có dữ liệu thật)
    // =====================================================================
    private void seedDemoData() {
        leader = new Leader("U01", "an", "123", "An Nguyen", "an@teamquest.dev");
        Member m1 = new Member("U02", "binh", "123", "Binh Tran", "binh@teamquest.dev");
        Member m2 = new Member("U03", "chi", "123", "Chi Le", "chi@teamquest.dev");

        team = new Team("TM01", "Alpha Squad", leader);
        team.addMember(m1);
        team.addMember(m2);
        leader.setManagedTeam(team);
        project = new Project("PJ01", "TEAM-QUEST", "Do an mon Lap trinh ung dung",
                java.time.LocalDate.now().plusMonths(1));

        users.addAll(List.of(leader, m1, m2));

        addSeedTask("Design database schema", "Draw ERD for all entities.",
                Difficulty.MEDIUM, LocalDateTime.now().plusDays(5));
        addSeedTask("Build login screen", "Swing form with validation.",
                Difficulty.EASY, LocalDateTime.now().plusHours(10));   // khẩn cấp -> tô đỏ
        addSeedTask("Implement Gson persistence", "Save/load database.json.",
                Difficulty.HARD, LocalDateTime.now().plusDays(10));
    }

    private void addSeedTask(String title, String desc, Difficulty d, LocalDateTime dl) {
        Task t = new Task(nextTaskId(), title, desc, d, dl);
        board.postTask(t);
        project.addTask(t);
    }

    private void initView() {
        for (User u : users) view.getUserCombo().addItem(u);
        currentUser = users.get(0);
        // [LOGIC][SmartAssigner] View dùng hàm này để tô đỏ task khẩn cấp
        view.setUrgentPredicate(smartAssigner::isUrgent);
        view.clearForm(nextTaskId());
        view.setStatusBar("Welcome to TEAM-QUEST. Select a task or create a new one.");
    }

    // =====================================================================
    // [LISTENER] Gắn toàn bộ sự kiện tại một chỗ
    // =====================================================================
    private void attachListeners() {
        // Đổi người dùng (giả lập đăng nhập) -> đổi quyền các nút
        view.getUserCombo().addActionListener(e -> {
            currentUser = (User) view.getUserCombo().getSelectedItem();
            updateButtons();
            updateProfileInfo();
        });

        // [LISTENER] Click dòng trong bảng -> đổ dữ liệu ngược lên Form
        // (getValueIsAdjusting = true khi đang kéo chuột; chỉ xử lý khi đã "chốt")
        view.getTable().getSelectionModel().addListSelectionListener(e -> {
            if (e.getValueIsAdjusting()) return;
            Task selected = view.getSelectedTask();
            if (selected != null) view.showTask(selected);
            updateButtons();
        });

        // [LISTENER] Bộ lọc bảng
        view.getCbFilterStatus().addActionListener(e -> refreshTable());
        view.getCbFilterDifficulty().addActionListener(e -> refreshTable());

        // [LISTENER] Các nút chức năng
        view.getBtnPost().addActionListener(e -> onPostTask());
        view.getBtnClaim().addActionListener(e -> onClaimTask());
        view.getBtnSubmit().addActionListener(e -> onSubmit());
        view.getBtnApprove().addActionListener(e -> onApprove());
        view.getBtnReject().addActionListener(e -> onReject());
        view.getBtnAutoAssign().addActionListener(e -> onAutoAssign());
        view.getBtnClear().addActionListener(e -> view.clearForm(nextTaskId()));
    }

    // =====================================================================
    // Xử lý từng nút
    // =====================================================================

    /** Nút Post Task (Leader): đọc Form -> tạo Task -> QuestBoard.postTask. */
    private void onPostTask() {
        try {
            String id = view.getTaskIdText().isEmpty() ? nextTaskId() : view.getTaskIdText();
            Task task = new Task(id, view.getTitleText(), view.getDescriptionText(),
                    view.getSelectedDifficulty(), view.getDeadline());
            // Status luôn = TODO khi mới đăng (Task constructor đã set), bỏ qua giá trị combobox.

            // [LOGIC] Leader kiểm tra hợp lệ -> QuestBoard.postTask(task)
            ((Leader) currentUser).createTask(task);
            board.postTask(task);
            project.addTask(task);          // giữ Project đồng bộ (SmartAssigner.scanUrgentTasks dùng)

            view.clearForm(nextTaskId());
            refreshTable();
            view.selectTask(task);
            view.setStatusBar("Posted task " + task.getTaskId() + ".");
        } catch (IllegalArgumentException | IllegalStateException ex) {
            showError(ex.getMessage());
        }
    }

    /** Nút Claim Task (Member): QuestBoard.claimTask(task, member). */
    private void onClaimTask() {
        Task task = view.getSelectedTask();
        if (task == null) return;
        // [LOGIC] QuestBoard.claimTask -> Member.claimTask (TODO -> DOING, gán assignee)
        boolean ok = board.claimTask(task, (Member) currentUser);
        if (ok) view.setStatusBar("You claimed " + task.getTaskId() + ".");
        else showError("Cannot claim this task (already taken?).");
        afterAction(task);
    }

    /** Nút Submit (Member): hỏi file + ghi chú -> tạo Submission -> Member.submitTask. */
    private void onSubmit() {
        Task task = view.getSelectedTask();
        if (task == null) return;

        JTextField tfFile = new JTextField(22);
        JTextField tfNote = new JTextField(22);
        JPanel panel = new JPanel(new GridLayout(0, 1, 4, 4));
        panel.add(new JLabel("File path / link:"));
        panel.add(tfFile);
        panel.add(new JLabel("Note:"));
        panel.add(tfNote);
        int r = JOptionPane.showConfirmDialog(view, panel, "Submit " + task.getTaskId(),
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (r != JOptionPane.OK_OPTION) return;

        try {
            Member member = (Member) currentUser;
            // [LOGIC] Tạo Submission rồi gọi Member.submitTask (DOING -> REVIEW)
            Submission sub = new Submission("SUB-" + String.format("%03d", ++submissionCounter),
                    task, member, tfFile.getText().trim(), tfNote.getText().trim());
            member.submitTask(task, sub);
            pendingSubmissions.put(task.getTaskId(), sub);
            view.setStatusBar("Submitted " + task.getTaskId() + " - waiting for Leader review.");
        } catch (IllegalStateException ex) {
            showError(ex.getMessage());
        }
        afterAction(task);
    }

    /**
     * Nút Approve (Leader): Leader.approveSubmission + GamificationService.grantReward.
     * Đây là chỗ nối Gamification: cộng XP/Coin vào PlayerProfile của Member.
     */
    private void onApprove() {
        Task task = view.getSelectedTask();
        Submission sub = task == null ? null : pendingSubmissions.get(task.getTaskId());
        if (sub == null) return;
        try {
            Member member = sub.getSubmitter();
            PlayerProfile p = member.getProfile();
            int levelBefore = p.getLevel();

            // [LOGIC] 1) Leader duyệt: Submission -> DONE, Task -> DONE
            ((Leader) currentUser).approveSubmission(sub);
            // [LOGIC][GamificationService] 2) Trao thưởng: gainXp + addCoin trong PlayerProfile
            gamification.grantReward(member, task);
            // (Nếu muốn phạt trễ hạn: gamification.applyPenalty(member, task);)

            pendingSubmissions.remove(task.getTaskId());
            String msg = String.format("Approved %s: %s received +%d XP, +%d coin.",
                    task.getTaskId(), member.getFullName(), task.calculateXp(), task.calculateCoin());
            if (p.getLevel() > levelBefore) msg += " LEVEL UP -> " + p.getLevel() + "!";
            view.setStatusBar(msg);
        } catch (IllegalStateException ex) {
            showError(ex.getMessage());
        }
        afterAction(task);
    }

    /** Nút Reject (Leader): Leader.rejectSubmission -> task quay về DOING. */
    private void onReject() {
        Task task = view.getSelectedTask();
        Submission sub = task == null ? null : pendingSubmissions.get(task.getTaskId());
        if (sub == null) return;
        try {
            // [LOGIC] Submission -> DOING, Task -> DOING (Member phải làm lại)
            ((Leader) currentUser).rejectSubmission(sub);
            pendingSubmissions.remove(task.getTaskId());
            view.setStatusBar("Rejected " + task.getTaskId() + " - sent back to " +
                    task.getAssignee().getFullName() + ".");
        } catch (IllegalStateException ex) {
            showError(ex.getMessage());
        }
        afterAction(task);
    }

    /** Nút Auto-Assign (Leader): SmartAssigner giao task cho thành viên rảnh nhất. */
    private void onAutoAssign() {
        Task task = view.getSelectedTask();
        if (task == null) return;
        try {
            // [LOGIC][SmartAssigner] findFreestMember + claimTask
            smartAssigner.autoAssign(task, team);
            view.setStatusBar("Auto-assigned " + task.getTaskId() + " to " +
                    task.getAssignee().getFullName() + ".");
        } catch (IllegalStateException ex) {
            showError(ex.getMessage());
        }
        afterAction(task);
    }

    // =====================================================================
    // Đồng bộ giao diện
    // =====================================================================

    /** Nạp lại bảng theo bộ lọc hiện tại. */
    private void refreshTable() {
        Task keep = view.getSelectedTask();     // nhớ dòng đang chọn để chọn lại sau khi nạp
        TaskStatus fs = view.getFilterStatus();
        Difficulty fd = view.getFilterDifficulty();

        // [LOGIC][QuestBoard] filterByStatus + filterByDifficulty (null = ALL = không lọc)
        List<Task> result = new ArrayList<>(board.getAllTasks());
        if (fs != null) result.retainAll(board.filterByStatus(fs));
        if (fd != null) result.retainAll(board.filterByDifficulty(fd));

        view.getTableModel().setTasks(result);
        if (keep != null) view.selectTask(keep);
        int done = (int) Math.round(project.getProgress() * 100);
        if (view.getSelectedTask() == null) {
            view.setStatusBar("Showing " + result.size() + " task(s) | Project progress: " + done + "%");
        }
    }

    /** Gọi sau mỗi hành động: nạp bảng, chọn lại task, đổ lại form, cập nhật nút + profile. */
    private void afterAction(Task task) {
        refreshTable();
        view.selectTask(task);
        Task sel = view.getSelectedTask();
        if (sel != null) view.showTask(sel);
        updateButtons();
        updateProfileInfo();
    }

    /**
     * Phân quyền + trạng thái nút. Sửa luật tại đây.
     *   Post / Auto-Assign / Approve / Reject : chỉ Leader
     *   Claim / Submit                         : chỉ Member
     * Ngoài ra nút chỉ bật khi task đang chọn ở đúng trạng thái.
     */
    private void updateButtons() {
        boolean isLeader = currentUser instanceof Leader;
        boolean isMember = currentUser instanceof Member;
        Task t = view.getSelectedTask();

        boolean freeTodo = t != null && t.getStatus() == TaskStatus.TODO && t.getAssignee() == null;
        boolean mine = t != null && isMember && t.getAssignee() == currentUser;
        boolean pending = t != null && pendingSubmissions.containsKey(t.getTaskId());

        view.getBtnPost().setEnabled(isLeader && t == null);      // t == null: đang ở form trống
        view.getBtnAutoAssign().setEnabled(isLeader && freeTodo);
        view.getBtnClaim().setEnabled(isMember && freeTodo);
        view.getBtnSubmit().setEnabled(mine && t.getStatus() == TaskStatus.DOING);
        view.getBtnApprove().setEnabled(isLeader && pending);
        view.getBtnReject().setEnabled(isLeader && pending);
    }

    /** Hiển thị PlayerProfile: Member xem của mình, Leader xem cả team (để thấy XP/Coin tăng sau Approve). */
    private void updateProfileInfo() {
        StringBuilder sb = new StringBuilder();
        if (currentUser instanceof Member m) {
            sb.append(formatProfile(m));
        } else {
            List<String> parts = new ArrayList<>();
            for (Member m : team.getMembers()) parts.add(formatProfile(m));
            sb.append(String.join("   ||   ", parts));
        }
        view.setProfileText(sb.toString());
    }

    private String formatProfile(Member m) {
        PlayerProfile p = m.getProfile();
        return String.format("%s: Lv %d | XP %d/%d | Coin %d | HP %d/%d | Workload %d",
                m.getFullName(), p.getLevel(), p.getXp(), p.getXpToNextLevel(),
                p.getCoin(), p.getHp(), p.getMaxHp(), m.getWorkload());
    }

    // =====================================================================
    // Tiện ích
    // =====================================================================
    private String nextTaskId() {
        String id;
        do { id = String.format("TASK-%03d", ++taskCounter); } while (board.findById(id) != null);
        return id;
    }

    private void showError(String msg) {
        JOptionPane.showMessageDialog(view, msg, "Cannot perform action", JOptionPane.WARNING_MESSAGE);
    }
}
