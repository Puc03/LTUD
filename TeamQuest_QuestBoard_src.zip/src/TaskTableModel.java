import javax.swing.table.AbstractTableModel;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/** [VIEW helper] Chuyển List<Task> thành dữ liệu cho JTable. Thêm/bớt cột sửa ở COLUMNS + getValueAt. */
public class TaskTableModel extends AbstractTableModel {
    private static final String[] COLUMNS = {"ID", "Title", "Difficulty", "Deadline", "Status", "Assignee"};
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    private List<Task> tasks = new ArrayList<>();

    public void setTasks(List<Task> tasks) {
        this.tasks = new ArrayList<>(tasks);
        fireTableDataChanged();
    }

    public Task getTaskAt(int modelRow) { return tasks.get(modelRow); }

    public int indexOf(Task t) { return tasks.indexOf(t); }

    @Override public int getRowCount() { return tasks.size(); }
    @Override public int getColumnCount() { return COLUMNS.length; }
    @Override public String getColumnName(int c) { return COLUMNS[c]; }

    @Override
    public Object getValueAt(int row, int col) {
        Task t = tasks.get(row);
        return switch (col) {
            case 0 -> t.getTaskId();
            case 1 -> t.getTitle();
            case 2 -> t.getDifficulty();
            case 3 -> t.getDeadline() == null ? "" : t.getDeadline().format(FMT);
            case 4 -> t.getStatus();
            case 5 -> t.getAssignee() == null ? "-" : t.getAssignee().getFullName();
            default -> "";
        };
    }
}
