public class SubTask {
    private String name;
    private int bonusXp;
    private boolean isCompleted;

    public SubTask(String name, int bonusXp) {
        this.name = name;
        this.bonusXp = bonusXp;
        this.isCompleted = false; // Mới tạo ra thì mặc định chưa hoàn thành
    }

    public void complete() {
        this.isCompleted = true;
    }

    // [MỚI] Getter (Task.calculateXp() cần đọc bonusXp)
    public String getName() { return name; }
    public int getBonusXp() { return bonusXp; }
    public boolean isCompleted() { return isCompleted; }
}
