// Đồng bộ với UML: TODO -> DOING -> REVIEW -> DONE
// (bản tuần 2 cũ là IN_PROGRESS / CANCELLED, đã đổi cho khớp sơ đồ)
public enum TaskStatus {
    TODO,       // Chưa ai nhận
    DOING,      // Đã có người nhận, đang làm
    REVIEW,     // Đã nộp, chờ Leader duyệt
    DONE        // Leader đã duyệt
}
