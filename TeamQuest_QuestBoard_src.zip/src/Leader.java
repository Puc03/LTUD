public class Leader extends User {
    private Team managedTeam; // Nhóm trưởng thì phải quản lý một Nhóm

    public Leader(String id, String username, String password, String fullName, String email) {
        super(id, username, password, fullName, email);
    }

    @Override
    public String getRole() {
        return "LEADER";
    }

    public void setManagedTeam(Team team) { this.managedTeam = team; }
    public Team getManagedTeam() { return managedTeam; }

    // Kiểm tra dữ liệu task hợp lệ trước khi đăng lên QuestBoard
    public void createTask(Task task) {
        if (task == null || task.getTitle() == null || task.getTitle().isBlank()) {
            throw new IllegalArgumentException("Task title must not be empty.");
        }
    }

    // Duyệt: Submission -> DONE, Task -> DONE. (XP/Coin do GamificationService trao)
    public void approveSubmission(Submission submission) {
        if (submission.getStatus() != TaskStatus.REVIEW) {
            throw new IllegalStateException("Submission is not waiting for review.");
        }
        submission.approve();
        submission.getTask().updateStatus(TaskStatus.DONE);
        submission.getSubmitter().onTaskFinished();
    }

    // Từ chối: bắt làm lại -> Task quay về DOING
    public void rejectSubmission(Submission submission) {
        if (submission.getStatus() != TaskStatus.REVIEW) {
            throw new IllegalStateException("Submission is not waiting for review.");
        }
        submission.reject();
        submission.getTask().updateStatus(TaskStatus.DOING);
    }
}
