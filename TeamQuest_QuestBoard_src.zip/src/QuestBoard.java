import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/** Bảng nhiệm vụ chung của hệ thống (UML: QuestBoard). */
public class QuestBoard {
    private List<Task> tasks = new ArrayList<>();

    public void postTask(Task task) {
        if (task == null) throw new IllegalArgumentException("Task is null.");
        if (findById(task.getTaskId()) != null) {
            throw new IllegalArgumentException("Task ID already exists: " + task.getTaskId());
        }
        tasks.add(task);
    }

    public void removeTask(Task task) { tasks.remove(task); }

    public boolean claimTask(Task task, Member member) {
        if (!tasks.contains(task)) return false;
        return member.claimTask(task);
    }

    public List<Task> filterByStatus(TaskStatus status) {
        return tasks.stream().filter(t -> t.getStatus() == status).collect(Collectors.toList());
    }

    public List<Task> filterByDifficulty(Difficulty difficulty) {
        return tasks.stream().filter(t -> t.getDifficulty() == difficulty).collect(Collectors.toList());
    }

    // [MỚI] Hàm hỗ trợ cho GUI
    public List<Task> getAllTasks() { return Collections.unmodifiableList(tasks); }

    public Task findById(String taskId) {
        return tasks.stream().filter(t -> t.getTaskId().equals(taskId)).findFirst().orElse(null);
    }
}
