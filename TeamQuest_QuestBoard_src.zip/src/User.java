public abstract class User {
    // Dùng protected để Member và Leader có thể xài chung
    protected String id;
    protected String username;
    protected String password;
    protected String fullName;
    protected String email;

    // Constructor khởi tạo dữ liệu
    public User(String id, String username, String password, String fullName, String email) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.fullName = fullName;
        this.email = email;
    }

    public boolean login(String username, String password) {
        return this.username.equals(username) && this.password.equals(password);
    }

    public void logout() {
        // Logic đăng xuất
    }

    // Abstract method: Ép các class con phải tự định nghĩa Role
    public abstract String getRole();

    // [MỚI] Getter cho GUI dùng
    public String getId() { return id; }
    public String getFullName() { return fullName; }

    // [MỚI] JComboBox sẽ gọi toString() để hiển thị tên
    @Override
    public String toString() {
        return fullName + " (" + getRole() + ")";
    }
}
