import java.util.ArrayList;
import java.util.List;

public class Team {
    private String teamId;
    private String teamName;
    private Leader leader;          // 1 Nhóm trưởng
    private List<Member> members;   // Danh sách thành viên

    public Team(String teamId, String teamName, Leader leader) {
        this.teamId = teamId;
        this.teamName = teamName;
        this.leader = leader;
        this.members = new ArrayList<>(); // Khởi tạo danh sách rỗng
    }

    public void addMember(Member member) {
        this.members.add(member);
    }

    public void removeMember(Member member) {
        this.members.remove(member);
    }

    // Getters
    public List<Member> getMembers() {
        return members;
    }

    public Leader getLeader() {
        return leader;
    }
}
