public class Member extends User {
    // Member sở hữu 1 profile chứa các chỉ số HP, XP
    private PlayerProfile profile;
    // Số task đang gánh (DOING/REVIEW). Dùng counter thay vì List<Task>
    // để tránh vòng tham chiếu Task <-> Member khi lưu JSON bằng Gson.
    private int workload;

    public Member(String id, String username, String password, String fullName, String email) {
        super(id, username, password, fullName, email);
        this.profile = new PlayerProfile();
        this.workload = 0;
    }

    @Override
    public String getRole() {
        return "MEMBER";
    }

    // Nhận việc: chỉ được nhận task đang TODO và chưa có người nhận
    public boolean claimTask(Task task) {
        if (task == null || task.getStatus() != TaskStatus.TODO || task.getAssignee() != null) {
            return false;
        }
        task.assignTo(this);
        task.updateStatus(TaskStatus.DOING);
        workload++;
        return true;
    }

    // Nộp bài: phải là người đã nhận và task đang DOING
    public void submitTask(Task task, Submission submission) {
        if (task.getAssignee() != this) {
            throw new IllegalStateException("You are not the assignee of this task.");
        }
        if (task.getStatus() != TaskStatus.DOING) {
            throw new IllegalStateException("Only tasks in DOING status can be submitted.");
        }
        submission.submit();                       // Submission -> REVIEW
        task.updateStatus(TaskStatus.REVIEW);      // Task -> REVIEW (chờ Leader duyệt)
    }

    // UML: getWorkload()
    public int getWorkload() { return workload; }

    // Leader gọi khi duyệt xong để giảm tải
    public void onTaskFinished() { if (workload > 0) workload--; }

    public PlayerProfile getProfile() { return profile; }
}
