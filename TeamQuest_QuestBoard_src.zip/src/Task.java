import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Task theo đúng UML: taskId, title, description, difficulty, deadline, status, assignee.
 * Implements Rewardable -> XP/Coin tính theo độ khó.
 * (Giữ lại subTasks của bản tuần 2.)
 */
public class Task implements Rewardable {
    private String taskId;
    private String title;
    private String description;
    private Difficulty difficulty;
    private LocalDateTime deadline;
    private TaskStatus status;
    private Member assignee;             // null = chưa ai nhận
    private List<SubTask> subTasks;

    public Task(String taskId, String title, String description,
                Difficulty difficulty, LocalDateTime deadline) {
        this.taskId = taskId;
        this.title = title;
        this.description = description;
        this.difficulty = difficulty;
        this.deadline = deadline;
        this.status = TaskStatus.TODO;   // Vừa sinh ra mặc định là TODO
        this.assignee = null;
        this.subTasks = new ArrayList<>();
    }

    // ---- Behavior theo UML ----
    public void assignTo(Member member) { this.assignee = member; }

    public void updateStatus(TaskStatus status) { this.status = status; }

    public boolean isOverdue() {
        return deadline != null && status != TaskStatus.DONE
                && LocalDateTime.now().isAfter(deadline);
    }

    public void addSubTask(SubTask subTask) { this.subTasks.add(subTask); }

    // ---- Rewardable: thưởng theo độ khó (chỉnh bảng số ở đây) ----
    @Override
    public int calculateXp() {
        int base = switch (difficulty) {
            case EASY -> 50;
            case MEDIUM -> 100;
            case HARD -> 200;
        };
        for (SubTask st : subTasks) {
            if (st.isCompleted()) base += st.getBonusXp();
        }
        return base;
    }

    @Override
    public int calculateCoin() {
        return switch (difficulty) {
            case EASY -> 10;
            case MEDIUM -> 25;
            case HARD -> 50;
        };
    }

    // ---- Getter / Setter ----
    public String getTaskId() { return taskId; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public Difficulty getDifficulty() { return difficulty; }
    public void setDifficulty(Difficulty difficulty) { this.difficulty = difficulty; }
    public LocalDateTime getDeadline() { return deadline; }
    public void setDeadline(LocalDateTime deadline) { this.deadline = deadline; }
    public TaskStatus getStatus() { return status; }
    public Member getAssignee() { return assignee; }
    public List<SubTask> getSubTasks() { return subTasks; }
}
