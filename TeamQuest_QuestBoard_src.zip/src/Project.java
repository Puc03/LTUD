import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Project {
    private String projectId;
    private String projectName;
    private String description;
    private LocalDate deadline;     // Dùng LocalDate để quản lý ngày tháng chuẩn xác
    private String status;
    private List<Task> tasks;       // 1 Dự án chứa nhiều Nhiệm vụ

    public Project(String projectId, String projectName, String description, LocalDate deadline) {
        this.projectId = projectId;
        this.projectName = projectName;
        this.description = description;
        this.deadline = deadline;
        this.status = "OPEN";
        this.tasks = new ArrayList<>();
    }

    public void addTask(Task task) {
        this.tasks.add(task);
    }

    public void removeTask(Task task) {
        this.tasks.remove(task);
    }

    public double getProgress() {
        // Tổng số task DONE chia cho tổng số task hiện có
        if (tasks.isEmpty()) return 0.0;
        long done = tasks.stream().filter(t -> t.getStatus() == TaskStatus.DONE).count();
        return (double) done / tasks.size();
    }

    // [MỚI] Getter cho SmartAssigner / GUI
    public List<Task> getTasks() { return tasks; }
    public String getProjectName() { return projectName; }

    public boolean isOverdue() {
        // So sánh ngày hiện tại với deadline
        return LocalDate.now().isAfter(this.deadline);
    }
}
