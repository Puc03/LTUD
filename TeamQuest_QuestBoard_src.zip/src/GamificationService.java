import java.time.Duration;
import java.time.LocalDateTime;

/** Trao thưởng / phạt (UML: GamificationService). */
public class GamificationService {
    private int hpPenaltyPerDay = 50;

    // Cộng XP + Coin vào PlayerProfile của Member. Số lượng lấy từ Task (Rewardable).
    public void grantReward(Member member, Task task) {
        PlayerProfile p = member.getProfile();
        p.gainXp(task.calculateXp());
        p.addCoin(task.calculateCoin());
    }

    // Trừ HP theo số ngày trễ hạn
    public void applyPenalty(Member member, Task task) {
        if (!task.isOverdue()) return;
        long days = Math.max(1, Duration.between(task.getDeadline(), LocalDateTime.now()).toDays());
        member.getProfile().loseHp((int) (days * hpPenaltyPerDay));
    }
}
